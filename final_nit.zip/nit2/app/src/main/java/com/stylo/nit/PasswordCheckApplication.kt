package com.stylo.nit

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PasswordCheckApplication : Application()