package com.stylo.nit

import com.stylo.nit.RetrofitApi.ApiService
import com.stylo.nit.RetrofitApi.LoginRequest
import com.stylo.nit.RetrofitApi.LoginResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CredentialRepository @Inject constructor(
    private val apiService: ApiService
) {

    suspend fun validateCredentials(credential: LoginRequest): Result<LoginResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.login(credential)
                Result.success(response)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun fetchArtworksWithKeypass(keypass: String): Result<com.stylo.nit.RetrofitApi.ArtResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val fullUrl = "https://nit3213api.onrender.com/dashboard/$keypass"
                val response = apiService.getArtList(fullUrl)
                Result.success(response)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
