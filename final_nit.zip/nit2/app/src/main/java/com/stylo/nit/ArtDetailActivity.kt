package com.stylo.nit

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.stylo.nit.databinding.ActivityArtDetailBinding

class ArtDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityArtDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityArtDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get data from intent
        val title = intent.getStringExtra("title")
        val artist = intent.getStringExtra("artist")
        val medium = intent.getStringExtra("medium")
        val year = intent.getIntExtra("year", 0)
        val description = intent.getStringExtra("description")

        // Bind to UI
        binding.tvDetailTitle.text = title
        binding.tvDetailArtist.text = "Artist: $artist"
        binding.tvDetailMedium.text = "Medium: $medium"
        binding.tvDetailYear.text = "Year: $year"
        binding.tvDetailDescription.text = "Description: $description"
    }
}
